# CSIS 3275 Software Engineering – Practice Lab (Book Version)

## II- Practical

**Instructions:** Develop a Java Program solution based on the requirements below.

**General Description:**
The program will prompt the user to enter book data such as ISBN, title, author,
price, year published and category. The program will save these data in the database.
The program will also have the capability to project a bulk-order discount table
based on the quantity ordered. Other specifications will be specified below.

**You must use H2 as your database for this lab.**

---

## Program Requirements

### 1. Project Setup
Create a Spring Boot MVC Project that will have the capability of using **H2**,
**JUNIT** and **MOCKITO**. You can add other dependencies (hamcrest, webjars etc.)
if you intend to use their capabilities. The output of this step is your updated
POM file that contains all the dependencies that you need. You will also create
the necessary html files to show your data.

### 2. Database (JPA)
Implement the database in your project by creating table or tables using JPA.

- a. Codes for display, update, delete and edit records
- b. A plain old java object (POJO) of the needed data fields of your database.
     You will use these fields as your temporary storage for entry and output of data.
     Derive your POJO files based on the requirements below (Number 4).

### 3. Controllers and Repositories
Create your controllers and repositories.

### 4. Index Page (Display)
Your index page should show the following fields and interface:

| ISBN | Title | Author | Price | Year | Category | Actions |
|------|-------|--------|-------|------|----------|---------|
| 978-01 | Clean Code | Robert Martin | 45.00 | 2008 | Non-Fiction | [Edit] [Delete] [Discount] |
| 978-02 | The Hobbit | J.R.R. Tolkien | 25.00 | 1937 | Fiction | [Edit] [Delete] [Discount] |

**Take note of the following:**
- The page displays the current data that is already inside the table. If your
  page is new, it will only contain the column headers.
- The buttons available are **add**, **edit**, **delete** and **discount table**.

### 5. Add Page
When the user clicks add, an HTML file will be shown where the user can add a new entry:

```
┌──────────────── Add Book ────────────────┐
│                                           │
│  ISBN:     [ 978-03             ]         │
│  Title:    [ Effective Java     ]         │
│  Author:   [ Joshua Bloch       ]         │
│  Price:    [ 50.00              ]         │
│  Year:     [ 2017               ]         │
│  Category: [ -- Select --     ▼ ]         │
│                                           │
│     [ Save ]        [ Back ]              │
└───────────────────────────────────────────┘
```

**Note:** The Category is a combo box that shows two options: **Fiction** or **Non-Fiction**.
When the back button is clicked, it goes back to the index page.

### 6. Validation
Provide the necessary validations needed by the input boxes (required fields, positive
price, year range, etc.).

### 7. Success Message
Upon submission, the display html will be shown again with the new entry.
Add a message to signify a successful entry.

### 8. Duplicate ISBN
If the user tries to enter a record of a book where the **ISBN is already existing**,
the system will not allow this situation, and an error message will be shown
("ISBN already exists!").

### 9. Edit Page
The user can choose a record he or she wants to edit by clicking the edit button of the book.
An Edit Book html file will be displayed.

**Note:**
- The system should be able to edit correctly any of the fields.
- The system should also automatically fill out the textboxes of the record chosen
  for editing.

### 10. Edit Success
The user will edit the record, and the edited record will be displayed after the
user clicked the save button. A successful edit message will be displayed.

### 11. Delete + Discount Table

**Delete:**
For deleting, the user will click the delete button on the record he or she wants
to delete, and a confirmation message will appear. If the user says OK, the record
will be deleted automatically otherwise the record will stay.

**Discount Table:**
When the Discount table button is clicked, it will go to another html file where
the bulk-order discount schedule based on quantity will be displayed.
Below is just a sample computation.

- Discount tiers:
  - 1 copy:    0% off
  - 5 copies:  5% off
  - 10 copies: 10% off
  - 25 copies: 15% off
  - 50 copies: 20% off
  - 100 copies: 25% off
- Non-Fiction gets an additional flat 5% off (educational discount).
- The formula for line total:
  ```java
  double lineTotal = quantity * price * (1 - discountRate);
  ```
- The above data is not saved in the database. It is computed on the fly using
  programming logic.
- When the user clicks back it will go back to the main page.

### 12. Dependency Injection
Your MVC should have an example of implementation of **dependency injection**.

### 13. Testing (JUnit + Mockito)
You will create a **JUNIT** and **MOCKITO** test for the class that implemented
the display, update and delete records interface. This will be your system under
test (SUT). Please follow the requirements below:
- a. You will use MOCKITO to mock the database dependencies of this Class.
- b. Create a test for adding, deleting, and displaying records.

### 14-18. Quality
- All tests should be passing.
- The program should be running correctly.
- The program should accurately produce the desired results.
- The program should have proper and ample documentation.
- The program should name its variables and controls mnemonically.

---

## Submission Guidelines
1. Allocate ample time for preparing your files for submission.
2. Check if you are submitting the correct file.
3. Name the file with your student number and first name as part of the file name.
4. Zip the proper files for submission.
5. Test the zipped file if it is opening and running properly.
6. Submit the file.
