package com.example.finalprepbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalPrepBookApplication {
    public static void main(String[] args) {
        SpringApplication.run(FinalPrepBookApplication.class, args);
    }
}
