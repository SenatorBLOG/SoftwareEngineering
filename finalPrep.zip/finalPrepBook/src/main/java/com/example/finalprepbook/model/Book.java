package com.example.finalprepbook.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

/**
 * ТРЕБОВАНИЕ №2b: POJO/Entity.
 * Поля выведены из ТРЕБОВАНИЯ №4: ISBN, Title, Author, Price, Year, Category.
 */
@Entity
@Table(name = "book")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ТРЕБОВАНИЕ №8: ISBN уникален (проверка на дубликат)
    @Column(unique = true, nullable = false)
    @NotBlank(message = "ISBN is required")
    private String isbn;

    @NotBlank(message = "Title is required")
    @Size(min = 1, max = 100, message = "Title must be 1-100 chars")
    private String title;

    @NotBlank(message = "Author is required")
    private String author;

    @Positive(message = "Price must be greater than zero")
    // @DecimalMin(value = "0.01", message = "Minimum price is 0.01")
    // @DecimalMax(value = "9999.99", message = "Maximum price is 9999.99")
    private double price;

    // ⚠️ ВАЖНО: YEAR — зарезервированное слово в H2 SQL (как и USER, ORDER,
    //    GROUP, DATE, TIME, COUNT, KEY, CHECK, TABLE, DAY, MONTH, HOUR и др.).
    //    Без @Column(name=...) Hibernate генерит SELECT ... year ... и H2 падает
    //    с "Syntax error, expected identifier". Всегда переименовывай колонку
    //    если имя поля совпадает с SQL-keyword.
    @Column(name = "publication_year")
    @Min(value = 1000, message = "Year must be >= 1000")
    @Max(value = 2100, message = "Year must be <= 2100")
    private int year;

    // combo box (ТРЕБОВАНИЕ №5): "Fiction" / "Non-Fiction"
    @NotBlank(message = "Category is required")
    private String category;

    // =================================================================
    // ЗАКОММЕНТИРОВАННЫЕ ПОЛЯ — раскомментить если препод добавит:
    // =================================================================

    // --- Количество копий (Integer может быть null) ---
    // @Column(nullable = true)                 // разрешить NULL
    // @Min(value = 0, message = "Copies cannot be negative")
    // private Integer copies;                   // Integer (не int!) чтобы null работал

    // --- "В наличии" (boolean / checkbox) ---
    // private boolean available;               // в HTML: <input type="checkbox" th:field="*{available}">

    // --- Email издателя с валидацией ---
    // @Email(message = "Invalid email format")
    // private String publisherEmail;

    // --- Телефон с паттерном ---
    // @Pattern(regexp = "\\d{3}-\\d{3}-\\d{4}", message = "Format: 123-456-7890")
    // private String publisherPhone;

    // --- Дата публикации (LocalDate) ---
    // import java.time.LocalDate;
    // import org.springframework.format.annotation.DateTimeFormat;
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    // @Past(message = "Publish date must be in the past")
    // private LocalDate publishDate;

    // --- Описание (textarea, большой текст) ---
    // @Column(length = 2000)
    // @Size(max = 2000)
    // private String description;

    // --- Enum вместо строки category ---
    // public enum Category { FICTION, NON_FICTION, SCIENCE, HISTORY, BIOGRAPHY }
    // @Enumerated(EnumType.STRING) private Category category;

    // --- BigDecimal для денег (правильнее чем double) ---
    // import java.math.BigDecimal;
    // @Positive private BigDecimal price;

    // --- OneToMany (например, список отзывов) ---
    // @OneToMany(mappedBy = "book", cascade = CascadeType.ALL, orphanRemoval = true)
    // private List<Review> reviews = new ArrayList<>();

    // =================================================================

    public Book() {}

    public Book(String isbn, String title, String author, double price, int year, String category) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.price = price;
        this.year = year;
        this.category = category;
    }

    // ---------------- Getters / Setters ----------------
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    // public Integer getCopies() { return copies; }
    // public void setCopies(Integer copies) { this.copies = copies; }
    // public boolean isAvailable() { return available; }
    // public void setAvailable(boolean available) { this.available = available; }
    // public LocalDate getPublishDate() { return publishDate; }
    // public void setPublishDate(LocalDate publishDate) { this.publishDate = publishDate; }
}
