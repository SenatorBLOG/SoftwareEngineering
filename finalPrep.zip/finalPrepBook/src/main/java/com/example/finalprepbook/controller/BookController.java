package com.example.finalprepbook.controller;

import com.example.finalprepbook.model.Book;
import com.example.finalprepbook.service.BookService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

/**
 * ТРЕБОВАНИЕ №3: Controller.
 * ТРЕБОВАНИЕ №12: Constructor Injection (пример DI) — BookService внедряется Spring-ом.
 */
@Controller
public class BookController {

    private final BookService service;

    // Constructor Injection — пример DI
    public BookController(BookService service) {
        this.service = service;
    }

    // ============== ТРЕБОВАНИЕ №4: Главная страница (список) ==============
    @GetMapping("/")
    public String index(Model model,
                        @RequestParam(value = "success", required = false) String success) {
        model.addAttribute("books", service.findAll());
        if (success != null) model.addAttribute("successMsg", success);
        return "index";
    }

    // ============== ТРЕБОВАНИЕ №5: Форма добавления ==============
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("book", new Book());
        return "add";
    }

    // ============== ТРЕБОВАНИЯ №6, №7, №8: Сохранение + валидация + дубликат ==============
    @PostMapping("/add")
    public String addBook(@Valid @ModelAttribute("book") Book book,
                          BindingResult result,
                          Model model) {
        // ТРЕБОВАНИЕ №6: если ошибки валидации — вернуть форму
        if (result.hasErrors()) {
            return "add";
        }
        // ТРЕБОВАНИЕ №8: дубликат ISBN
        if (service.existsByIsbn(book.getIsbn())) {
            model.addAttribute("duplicateError", "ISBN already exists!");
            return "add";
        }
        service.save(book);
        // ТРЕБОВАНИЕ №7: сообщение об успехе
        return "redirect:/?success=Added+Successfully";
    }

    // ============== ТРЕБОВАНИЕ №9: Форма редактирования ==============
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Book book = service.findById(id);
        if (book == null) return "redirect:/";
        model.addAttribute("book", book);
        return "edit";
    }

    // ============== ТРЕБОВАНИЕ №10: Сохранение изменений ==============
    @PostMapping("/edit/{id}")
    public String updateBook(@PathVariable Long id,
                             @Valid @ModelAttribute("book") Book book,
                             BindingResult result,
                             Model model) {
        if (result.hasErrors()) {
            return "edit";
        }
        // Проверка дубликата при смене ISBN (если новый ISBN уже у другой книги)
        Book existing = service.findById(id);
        if (existing != null
                && !existing.getIsbn().equals(book.getIsbn())
                && service.existsByIsbn(book.getIsbn())) {
            model.addAttribute("duplicateError", "ISBN already exists!");
            return "edit";
        }
        book.setId(id);
        service.save(book);
        return "redirect:/?success=Edited+Successfully";
    }

    // ============== ТРЕБОВАНИЕ №11: Удаление (с confirm на фронте) ==============
    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/?success=Deleted+Successfully";
    }

    // ============== ТРЕБОВАНИЕ №11: Discount Table ==============
    @GetMapping("/discount/{id}")
    public String discount(@PathVariable Long id, Model model) {
        Book book = service.findById(id);
        if (book == null) return "redirect:/";
        model.addAttribute("book", book);
        model.addAttribute("rows", service.buildDiscountTable(book));
        return "discount";
    }

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если препод попросит:
    // =================================================================

    // --- REST endpoint (JSON вместо HTML) ---
    // @GetMapping("/api/books")
    // @ResponseBody
    // public List<Book> apiList() { return service.findAll(); }

    // --- Search by title ---
    // @GetMapping("/search")
    // public String search(@RequestParam String q, Model model) {
    //     model.addAttribute("books", service.searchByTitle(q));
    //     return "index";
    // }

    // --- POST delete (REST-style) ---
    // @PostMapping("/delete/{id}")
    // public String deleteBookPost(@PathVariable Long id) { ... }
}
