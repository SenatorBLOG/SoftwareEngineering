package com.example.finalprepbook.repository;

import com.example.finalprepbook.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;
// import java.util.List;
// import java.util.Optional;

/**
 * ТРЕБОВАНИЕ №3: Repository.
 * JpaRepository уже даёт findAll, findById, save, deleteById — ничего писать не надо.
 */
public interface BookRepository extends JpaRepository<Book, Long> {

    // Проверка дубликата ISBN (ТРЕБОВАНИЕ №8)
    boolean existsByIsbn(String isbn);

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если попросят доп. query-методы:
    // =================================================================

    // --- Найти по ISBN ---
    // Optional<Book> findByIsbn(String isbn);

    // --- Поиск по названию (LIKE %...%) ---
    // List<Book> findByTitleContainingIgnoreCase(String title);

    // --- Поиск по автору ---
    // List<Book> findByAuthor(String author);

    // --- Фильтр по категории ---
    // List<Book> findByCategory(String category);

    // --- Сортировка по цене ---
    // List<Book> findAllByOrderByPriceDesc();

    // --- Кастомный JPQL ---
    // @Query("SELECT b FROM Book b WHERE b.price > :min")
    // List<Book> findExpensive(double min);
}
