package com.example.finalprepbook.service;

import com.example.finalprepbook.model.Book;
import com.example.finalprepbook.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * ТРЕБОВАНИЕ №12: Пример DEPENDENCY INJECTION.
 * Контроллер получает BookService через конструктор.
 * BookService получает BookRepository через конструктор.
 * Это и есть пример DI — Spring сам подставляет зависимости.
 */
@Service
public class BookService {

    private final BookRepository repository;

    // Constructor Injection (рекомендуемый способ DI)
    public BookService(BookRepository repository) {
        this.repository = repository;
    }

    public List<Book> findAll() {
        return repository.findAll();
    }

    public Book findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public boolean existsByIsbn(String isbn) {
        return repository.existsByIsbn(isbn);
    }

    public void save(Book book) {
        repository.save(book);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    // -------------------------------------------------------------
    // ТРЕБОВАНИЕ №11: Discount Table "на лету" (НЕ сохраняется в БД)
    // Скидки по количеству + доп. 5% для Non-Fiction.
    // -------------------------------------------------------------
    public List<DiscountRow> buildDiscountTable(Book book) {
        int[] quantities = {1, 5, 10, 25, 50, 100};
        double[] rates = {0.00, 0.05, 0.10, 0.15, 0.20, 0.25};

        // Доп. 5% для Non-Fiction (образовательная скидка)
        double extra = "Non-Fiction".equalsIgnoreCase(book.getCategory()) ? 0.05 : 0.00;

        List<DiscountRow> rows = new ArrayList<>();
        for (int i = 0; i < quantities.length; i++) {
            int qty = quantities[i];
            double rate = rates[i] + extra;
            double discountAmount = book.getPrice() * qty * rate;
            double lineTotal = book.getPrice() * qty * (1 - rate);
            rows.add(new DiscountRow(
                    qty,
                    round(rate * 100),
                    round(book.getPrice()),
                    round(discountAmount),
                    round(lineTotal)
            ));
        }
        return rows;
    }

    private double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    /** Строка таблицы скидок (используется в discount.html). */
    public static class DiscountRow {
        private final int quantity;
        private final double discountPercent;
        private final double unitPrice;
        private final double discountAmount;
        private final double lineTotal;

        public DiscountRow(int quantity, double discountPercent, double unitPrice,
                           double discountAmount, double lineTotal) {
            this.quantity = quantity;
            this.discountPercent = discountPercent;
            this.unitPrice = unitPrice;
            this.discountAmount = discountAmount;
            this.lineTotal = lineTotal;
        }
        public int getQuantity() { return quantity; }
        public double getDiscountPercent() { return discountPercent; }
        public double getUnitPrice() { return unitPrice; }
        public double getDiscountAmount() { return discountAmount; }
        public double getLineTotal() { return lineTotal; }
    }

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если препод попросит:
    // =================================================================

    // --- Цена с налогом (например GST 12%) ---
    // public double priceWithTax(Book b) { return b.getPrice() * 1.12; }

    // --- Сумма по всем книгам ---
    // public double totalInventoryValue() {
    //     return findAll().stream().mapToDouble(Book::getPrice).sum();
    // }

    // --- Альтернативные тиры скидок (если изменят правила) ---
    // int[] quantities = {1, 10, 50, 100, 500};
    // double[] rates   = {0.00, 0.10, 0.20, 0.30, 0.40};
}
