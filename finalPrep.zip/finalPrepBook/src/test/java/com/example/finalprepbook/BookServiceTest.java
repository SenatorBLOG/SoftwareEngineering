package com.example.finalprepbook;

import com.example.finalprepbook.model.Book;
import com.example.finalprepbook.repository.BookRepository;
import com.example.finalprepbook.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * ТРЕБОВАНИЕ №13: JUnit + Mockito тесты для CRUD.
 * @Mock         — мокаем зависимость (BookRepository).
 * @InjectMocks  — Mockito создаёт BookService и подставляет @Mock в его конструктор.
 *
 * Покрытие: add, delete, display (ТРЕБОВАНИЕ №13b) + findById, duplicate, discount.
 */
@ExtendWith(MockitoExtension.class)
class BookServiceTest {

    @Mock
    private BookRepository repository;

    @InjectMocks
    private BookService service;

    private Book sample;

    @BeforeEach
    void setUp() {
        sample = new Book("978-01", "Clean Code", "Robert Martin", 45.0, 2008, "Non-Fiction");
        sample.setId(1L);
    }

    // ---------- 1. DISPLAY (findAll) ----------
    @Test
    void testDisplayAllBooks() {
        Book b2 = new Book("978-02", "The Hobbit", "J.R.R. Tolkien", 25.0, 1937, "Fiction");
        when(repository.findAll()).thenReturn(Arrays.asList(sample, b2));

        List<Book> all = service.findAll();

        assertEquals(2, all.size());
        assertEquals("Clean Code", all.get(0).getTitle());
        verify(repository, times(1)).findAll();
    }

    // ---------- 2. ADD (save) ----------
    @Test
    void testAddBook() {
        when(repository.save(any(Book.class))).thenReturn(sample);

        service.save(sample);

        verify(repository, times(1)).save(sample);
    }

    // ---------- 3. DUPLICATE ISBN (ТРЕБОВАНИЕ №8) ----------
    @Test
    void testDuplicateIsbn() {
        when(repository.existsByIsbn("978-01")).thenReturn(true);

        assertTrue(service.existsByIsbn("978-01"));
        assertFalse(service.existsByIsbn("978-99"));
    }

    // ---------- 4. DELETE ----------
    @Test
    void testDeleteBook() {
        doNothing().when(repository).deleteById(1L);

        service.deleteById(1L);

        verify(repository, times(1)).deleteById(1L);
    }

    // ---------- 5. FIND BY ID ----------
    @Test
    void testFindById() {
        when(repository.findById(1L)).thenReturn(Optional.of(sample));

        Book found = service.findById(1L);

        assertNotNull(found);
        assertEquals("Clean Code", found.getTitle());
        assertEquals("Robert Martin", found.getAuthor());
    }

    // ---------- 6. FIND BY ID — NOT FOUND ----------
    @Test
    void testFindByIdNotFound() {
        when(repository.findById(999L)).thenReturn(Optional.empty());
        assertNull(service.findById(999L));
    }

    // ---------- 7. DISCOUNT TABLE ----------
    @Test
    void testDiscountTable() {
        List<BookService.DiscountRow> rows = service.buildDiscountTable(sample);

        assertEquals(6, rows.size()); // 6 tiers: 1, 5, 10, 25, 50, 100
        assertEquals(1, rows.get(0).getQuantity());
        // Цена за 1 копию Non-Fiction = 45 * (1 - 0.05 extra) = 42.75
        assertEquals(42.75, rows.get(0).getLineTotal(), 0.01);
    }

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если препод попросит:
    // =================================================================

    // --- Тест update ---
    // @Test
    // void testUpdateBook() {
    //     sample.setTitle("Clean Code 2nd Ed");
    //     when(repository.save(sample)).thenReturn(sample);
    //     service.save(sample);
    //     verify(repository).save(argThat(b -> "Clean Code 2nd Ed".equals(b.getTitle())));
    // }

    // --- Hamcrest assertThat (если требует Hamcrest) ---
    // import static org.hamcrest.MatcherAssert.assertThat;
    // import static org.hamcrest.Matchers.*;
    // assertThat(all, hasSize(2));
    // assertThat(all.get(0).getPrice(), greaterThan(0.0));
}
