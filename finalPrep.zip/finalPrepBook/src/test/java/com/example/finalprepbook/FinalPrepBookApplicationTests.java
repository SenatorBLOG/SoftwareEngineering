package com.example.finalprepbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Smoke-тест: проверяет что Spring context поднимается.
 * Все "настоящие" тесты бизнес-логики — в BookServiceTest.
 */
@SpringBootTest
class FinalPrepBookApplicationTests {

    @Test
    void contextLoads() {
    }
}
