package com.example.finalprep1.controller;

import com.example.finalprep1.model.LoanRecord;
import com.example.finalprep1.service.LoanService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

/**
 * ТРЕБОВАНИЕ №3: Controller.
 * ТРЕБОВАНИЕ №12: Constructor Injection (пример DI) — LoanService внедряется Spring-ом.
 */
@Controller
public class LoanController {

    private final LoanService service;

    // Constructor Injection — пример DI
    public LoanController(LoanService service) {
        this.service = service;
    }

    // ============== ТРЕБОВАНИЕ №4: Главная страница (список) ==============
    @GetMapping("/")
    public String index(Model model,
                        @RequestParam(value = "success", required = false) String success) {
        model.addAttribute("loans", service.findAll());
        if (success != null) model.addAttribute("successMsg", success);
        return "index";
    }

    // ============== ТРЕБОВАНИЕ №5: Форма добавления ==============
    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("loanRecord", new LoanRecord());
        return "add";
    }

    // ============== ТРЕБОВАНИЕ №6,7,8: Сохранение + валидация + дубликат ==============
    @PostMapping("/add")
    public String addLoan(@Valid @ModelAttribute("loanRecord") LoanRecord loanRecord,
                          BindingResult result,
                          Model model) {
        // ТРЕБОВАНИЕ №6: если ошибки валидации — вернуть форму
        if (result.hasErrors()) {
            return "add";
        }
        // ТРЕБОВАНИЕ №8: дубликат клиентского номера
        if (service.existsByClientNumber(loanRecord.getClientNumber())) {
            model.addAttribute("duplicateError", "Client number already exists!");
            return "add";
        }
        service.save(loanRecord);
        // ТРЕБОВАНИЕ №7: Flash-сообщение об успехе
        return "redirect:/?success=Added+Successfully";
    }

    // ============== ТРЕБОВАНИЕ №9: Форма редактирования ==============
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        LoanRecord loan = service.findById(id);
        if (loan == null) return "redirect:/";
        model.addAttribute("loanRecord", loan);
        return "edit";
    }

    // ============== ТРЕБОВАНИЕ №10: Сохранение изменений ==============
    @PostMapping("/edit/{id}")
    public String updateLoan(@PathVariable Long id,
                             @Valid @ModelAttribute("loanRecord") LoanRecord loanRecord,
                             BindingResult result,
                             Model model) {
        if (result.hasErrors()) {
            return "edit";
        }
        // Проверка дубликата: если clientNumber сменили и такой уже есть у ДРУГОЙ записи
        LoanRecord existing = service.findById(id);
        if (existing != null
                && !existing.getClientNumber().equals(loanRecord.getClientNumber())
                && service.existsByClientNumber(loanRecord.getClientNumber())) {
            model.addAttribute("duplicateError", "Client number already exists!");
            return "edit";
        }
        loanRecord.setId(id);
        service.save(loanRecord);
        return "redirect:/?success=Edited+Successfully";
    }

    // ============== ТРЕБОВАНИЕ №11: Удаление (с confirm на фронте) ==============
    @GetMapping("/delete/{id}")
    public String deleteLoan(@PathVariable Long id) {
        service.deleteById(id);
        return "redirect:/?success=Deleted+Successfully";
    }

    // ============== ТРЕБОВАНИЕ №11: Amortization table ==============
    @GetMapping("/amortization/{id}")
    public String amortization(@PathVariable Long id, Model model) {
        LoanRecord loan = service.findById(id);
        if (loan == null) return "redirect:/";
        model.addAttribute("loan", loan);
        model.addAttribute("schedule", service.buildSchedule(loan));
        return "amortization";
    }

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если препод попросит:
    // =================================================================

    // --- REST endpoint (JSON вместо HTML) ---
    // @GetMapping("/api/loans")
    // @ResponseBody
    // public List<LoanRecord> apiList() { return service.findAll(); }

    // --- Поиск по имени ---
    // @GetMapping("/search")
    // public String search(@RequestParam String q, Model model) {
    //     model.addAttribute("loans", service.searchByName(q));
    //     return "index";
    // }

    // --- POST-delete (более "правильный" REST, если попросят) ---
    // @PostMapping("/delete/{id}")
    // public String deleteLoanPost(@PathVariable Long id) { ... }
}
