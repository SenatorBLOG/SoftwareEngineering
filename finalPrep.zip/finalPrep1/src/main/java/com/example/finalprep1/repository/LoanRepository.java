package com.example.finalprep1.repository;

import com.example.finalprep1.model.LoanRecord;
import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;
// import java.util.List;

/**
 * ТРЕБОВАНИЕ №3: Repository.
 * JpaRepository уже даёт findAll, findById, save, deleteById — ничего писать не надо.
 */
public interface LoanRepository extends JpaRepository<LoanRecord, Long> {

    // Проверка дубликата по клиентскому номеру (ТРЕБОВАНИЕ №8)
    boolean existsByClientNumber(String clientNumber);

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если препод попросит дополнительные query:
    // =================================================================

    // --- Найти по clientNumber (вместо id) ---
    // Optional<LoanRecord> findByClientNumber(String clientNumber);

    // --- Поиск по имени (LIKE %...%) ---
    // List<LoanRecord> findByClientNameContainingIgnoreCase(String name);

    // --- Фильтр по типу кредита ---
    // List<LoanRecord> findByLoanType(String loanType);

    // --- Сортировка по сумме по убыванию ---
    // List<LoanRecord> findAllByOrderByLoanAmountDesc();

    // --- Кастомный JPQL запрос ---
    // @Query("SELECT l FROM LoanRecord l WHERE l.loanAmount > :min")
    // List<LoanRecord> findExpensive(double min);
}
