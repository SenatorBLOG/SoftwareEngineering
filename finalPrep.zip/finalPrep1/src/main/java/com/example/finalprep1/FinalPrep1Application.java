package com.example.finalprep1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalPrep1Application {

    public static void main(String[] args) {
        SpringApplication.run(FinalPrep1Application.class, args);
    }

}
