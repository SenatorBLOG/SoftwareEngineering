package com.example.finalprep1.service;

import com.example.finalprep1.model.LoanRecord;
import com.example.finalprep1.repository.LoanRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * ТРЕБОВАНИЕ №12: Пример DEPENDENCY INJECTION.
 * Контроллер получает LoanService через конструктор (constructor injection).
 * LoanService получает LoanRepository через конструктор.
 * Это и есть пример DI — Spring сам подставляет зависимости.
 */
@Service
public class LoanService {

    private final LoanRepository repository;

    // Constructor Injection (рекомендуемый способ DI в Spring)
    public LoanService(LoanRepository repository) {
        this.repository = repository;
    }

    public List<LoanRecord> findAll() {
        return repository.findAll();
    }

    public LoanRecord findById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public boolean existsByClientNumber(String clientNumber) {
        return repository.existsByClientNumber(clientNumber);
    }

    public void save(LoanRecord loan) {
        repository.save(loan);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }

    // -------------------------------------------------------------
    // ТРЕБОВАНИЕ №11: Генерация амортизационной таблицы "на лету"
    // (НЕ сохраняется в БД)
    // Формула: monthlyPayment = (loanAmount * monthlyRate) /
    //                           (1 - Math.pow(1 + monthlyRate, -termInMonths))
    // Personal = 6%, Business = 9%
    // -------------------------------------------------------------
    public List<AmortizationRow> buildSchedule(LoanRecord loan) {
        double annualRate = "Business".equalsIgnoreCase(loan.getLoanType()) ? 0.09 : 0.06;
        double monthlyRate = annualRate / 12.0;
        int termInMonths = loan.getYears() * 12;
        double loanAmount = loan.getLoanAmount();

        double monthlyPayment = (loanAmount * monthlyRate)
                / (1 - Math.pow(1 + monthlyRate, -termInMonths));

        List<AmortizationRow> rows = new ArrayList<>();
        double balance = loanAmount;
        for (int m = 1; m <= termInMonths; m++) {
            double interest = balance * monthlyRate;
            double principal = monthlyPayment - interest;
            balance = balance - principal;
            rows.add(new AmortizationRow(
                    m,
                    round(monthlyPayment),
                    round(interest),
                    round(principal),
                    round(Math.max(balance, 0))
            ));
        }
        return rows;
    }

    private double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    /** Одна строка таблицы амортизации (используется в amortization.html) */
    public static class AmortizationRow {
        private final int month;
        private final double payment;
        private final double interest;
        private final double principal;
        private final double balance;

        public AmortizationRow(int month, double payment, double interest, double principal, double balance) {
            this.month = month;
            this.payment = payment;
            this.interest = interest;
            this.principal = principal;
            this.balance = balance;
        }
        public int getMonth() { return month; }
        public double getPayment() { return payment; }
        public double getInterest() { return interest; }
        public double getPrincipal() { return principal; }
        public double getBalance() { return balance; }
    }

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если препод попросит:
    // =================================================================

    // --- Альтернативные ставки если появятся новые типы кредитов ---
    // if ("Mortgage".equalsIgnoreCase(loan.getLoanType())) annualRate = 0.045;
    // if ("Auto".equalsIgnoreCase(loan.getLoanType()))     annualRate = 0.075;

    // --- Годовая таблица вместо месячной (как в PDF стр.4) ---
    // for (int y = 1; y <= loan.getYears(); y++) { ... }
}
