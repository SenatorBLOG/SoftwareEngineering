package com.example.finalprep1.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

/**
 * ТРЕБОВАНИЕ №2b: POJO для полей БД.
 * Поля выведены из ТРЕБОВАНИЯ №4: Client No, Name, Loan Amount, Years, Loan Type.
 */
@Entity
public class LoanRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Уникальный номер клиента (ТРЕБОВАНИЕ №8: дубликат запрещён)
    @Column(unique = true, nullable = false)
    @NotBlank(message = "Client number is required")
    private String clientNumber;

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 50, message = "Name must be 2-50 chars")
    private String clientName;

    @Positive(message = "Loan amount must be greater than zero")
    // @DecimalMin(value = "100.0", message = "Minimum loan is 100")
    // @DecimalMax(value = "1000000.0", message = "Maximum loan is 1,000,000")
    private double loanAmount;

    @Min(value = 1, message = "Years must be at least 1")
    @Max(value = 30, message = "Years cannot exceed 30")
    private int years;

    // "Business" или "Personal" (ТРЕБОВАНИЕ №5: combo box)
    @NotBlank(message = "Loan type is required")
    private String loanType;

    // =================================================================
    // ЗАКОММЕНТИРОВАННЫЕ ПОЛЯ — раскомментить если препод добавит:
    // =================================================================

    // --- Если попросят поле "возраст" и оно может быть пустым ---
    // @Column(nullable = true)                 // разрешить NULL в БД
    // @Min(value = 18, message = "Must be 18+")
    // private Integer age;                     // Integer (не int!) чтобы null работал

    // --- Если попросят email с валидацией ---
    // @Email(message = "Invalid email format")
    // @NotBlank(message = "Email is required")
    // private String email;

    // --- Если попросят телефон с паттерном ---
    // @Pattern(regexp = "\\d{3}-\\d{3}-\\d{4}", message = "Format: 123-456-7890")
    // private String phone;

    // --- Если попросят дату рождения / дату получения кредита ---
    // import java.time.LocalDate;
    // import org.springframework.format.annotation.DateTimeFormat;
    // @DateTimeFormat(pattern = "yyyy-MM-dd")
    // @Past(message = "Date must be in the past")
    // private LocalDate birthDate;
    // @Future(message = "Due date must be in the future")
    // private LocalDate dueDate;

    // --- Если попросят чекбокс (boolean) "активный клиент" ---
    // private boolean active;                  // в HTML: <input type="checkbox" th:field="*{active}"/>

    // --- Если попросят radio buttons вместо combo box ---
    // (остаётся String loanType, меняется только HTML — см. add.html)

    // --- Если попросят большой текст (textarea) "комментарий" ---
    // @Column(length = 1000)
    // @Size(max = 1000)
    // private String notes;

    // --- Если попросят связь OneToMany (например, список платежей) ---
    // @OneToMany(mappedBy = "loan", cascade = CascadeType.ALL, orphanRemoval = true)
    // private List<Payment> payments = new ArrayList<>();

    // --- Если попросят enum вместо строки loanType ---
    // public enum LoanType { BUSINESS, PERSONAL, MORTGAGE, AUTO }
    // @Enumerated(EnumType.STRING)
    // private LoanType loanType;

    // --- Если попросят BigDecimal вместо double (для денег это правильнее) ---
    // import java.math.BigDecimal;
    // @Positive
    // private BigDecimal loanAmount;

    // =================================================================

    public LoanRecord() {}

    public LoanRecord(String clientNumber, String clientName, double loanAmount, int years, String loanType) {
        this.clientNumber = clientNumber;
        this.clientName = clientName;
        this.loanAmount = loanAmount;
        this.years = years;
        this.loanType = loanType;
    }

    // ---------------- Getters / Setters ----------------
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getClientNumber() { return clientNumber; }
    public void setClientNumber(String clientNumber) { this.clientNumber = clientNumber; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public double getLoanAmount() { return loanAmount; }
    public void setLoanAmount(double loanAmount) { this.loanAmount = loanAmount; }

    public int getYears() { return years; }
    public void setYears(int years) { this.years = years; }

    public String getLoanType() { return loanType; }
    public void setLoanType(String loanType) { this.loanType = loanType; }

    // public Integer getAge() { return age; }
    // public void setAge(Integer age) { this.age = age; }
    // public String getEmail() { return email; }
    // public void setEmail(String email) { this.email = email; }
    // public boolean isActive() { return active; }
    // public void setActive(boolean active) { this.active = active; }
    // public LocalDate getBirthDate() { return birthDate; }
    // public void setBirthDate(LocalDate birthDate) { this.birthDate = birthDate; }
}
