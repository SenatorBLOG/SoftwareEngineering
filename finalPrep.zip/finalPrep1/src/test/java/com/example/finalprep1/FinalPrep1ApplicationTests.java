package com.example.finalprep1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Smoke-тест: проверяет что Spring context поднимается.
 * Все "настоящие" тесты бизнес-логики — в LoanServiceTest.
 */
@SpringBootTest
class FinalPrep1ApplicationTests {

    @Test
    void contextLoads() {
    }
}
