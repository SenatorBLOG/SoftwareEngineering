package com.example.finalprep1;

import com.example.finalprep1.model.LoanRecord;
import com.example.finalprep1.repository.LoanRepository;
import com.example.finalprep1.service.LoanService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * ТРЕБОВАНИЕ №13: JUnit + Mockito тесты для класса, реализующего display/update/delete.
 * @Mock     — мокаем зависимость (LoanRepository)
 * @InjectMocks — Mockito создаёт LoanService и подставляет @Mock в его конструктор.
 *
 * Тесты: add, delete, display (ТРЕБОВАНИЕ №13c).
 */
@ExtendWith(MockitoExtension.class)
class LoanServiceTest {

    @Mock
    private LoanRepository repository;

    @InjectMocks
    private LoanService service;

    private LoanRecord sampleLoan;

    @BeforeEach
    void setUp() {
        sampleLoan = new LoanRecord("101", "John Doe", 3000.0, 3, "Personal");
        sampleLoan.setId(1L);
    }

    // ---------- 1. DISPLAY (findAll) ----------
    @Test
    void testDisplayAllLoans() {
        LoanRecord l2 = new LoanRecord("102", "Jane Doe", 5000.0, 2, "Business");
        when(repository.findAll()).thenReturn(Arrays.asList(sampleLoan, l2));

        List<LoanRecord> all = service.findAll();

        assertEquals(2, all.size());
        assertEquals("John Doe", all.get(0).getClientName());
        verify(repository, times(1)).findAll();
    }

    // ---------- 2. ADD (save) ----------
    @Test
    void testAddLoan() {
        when(repository.save(any(LoanRecord.class))).thenReturn(sampleLoan);

        service.save(sampleLoan);

        verify(repository, times(1)).save(sampleLoan);
    }

    // ---------- 3. DUPLICATE CHECK (ТРЕБОВАНИЕ №8) ----------
    @Test
    void testDuplicateClientNumber() {
        when(repository.existsByClientNumber("101")).thenReturn(true);

        assertTrue(service.existsByClientNumber("101"));
        assertFalse(service.existsByClientNumber("999"));
        // Проверяем что для "999" мок возвращает false (дефолт) — клиента нет
    }

    // ---------- 4. DELETE ----------
    @Test
    void testDeleteLoan() {
        doNothing().when(repository).deleteById(1L);

        service.deleteById(1L);

        verify(repository, times(1)).deleteById(1L);
    }

    // ---------- 5. FIND BY ID ----------
    @Test
    void testFindById() {
        when(repository.findById(1L)).thenReturn(Optional.of(sampleLoan));

        LoanRecord found = service.findById(1L);

        assertNotNull(found);
        assertEquals("John Doe", found.getClientName());
    }

    // ---------- 6. AMORTIZATION (формула из PDF стр.4) ----------
    @Test
    void testAmortizationSchedule() {
        LoanRecord loan = new LoanRecord("200", "Joy", 100000.0, 2, "Business");
        List<LoanService.AmortizationRow> rows = service.buildSchedule(loan);

        assertEquals(24, rows.size()); // 2 года = 24 месяца
        // Последний месяц должен обнулять баланс (~0)
        assertTrue(rows.get(23).getBalance() < 1.0);
    }

    // =================================================================
    // ЗАКОММЕНТИРОВАНО — если препод попросит:
    // =================================================================

    // --- Тест на update ---
    // @Test
    // void testUpdateLoan() {
    //     sampleLoan.setClientName("Updated Name");
    //     when(repository.save(sampleLoan)).thenReturn(sampleLoan);
    //     service.save(sampleLoan);
    //     verify(repository).save(argThat(l -> "Updated Name".equals(l.getClientName())));
    // }

    // --- Hamcrest assertThat (если требует Hamcrest) ---
    // import static org.hamcrest.MatcherAssert.assertThat;
    // import static org.hamcrest.Matchers.*;
    // assertThat(all, hasSize(2));
    // assertThat(all.get(0).getClientName(), is("John Doe"));
}
