package com.example.onepasscanada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnePassCanadaApplicationTests {

    @Test
    void contextLoads() {
    }

}
