package com.example.onepasscanada;

import com.example.onepasscanada.model.MembershipType;
import com.example.onepasscanada.model.User;
import com.example.onepasscanada.repository.UserRepository;
import com.example.onepasscanada.service.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mindrot.jbcrypt.BCrypt;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    UserService userService;

    @Test
    void register_newEmail_savesAndReturnsUser() {
        when(userRepository.existsByEmail("new@example.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        User result = userService.register("Alice", "new@example.com", "pass123", MembershipType.SILVER);

        assertEquals("Alice", result.getName());
        assertEquals("new@example.com", result.getEmail());
        assertEquals(MembershipType.SILVER, result.getMembershipType());
        assertEquals(MembershipType.SILVER.getMonthlyFee(), result.getBalance());
    }

    @Test
    void register_duplicateEmail_throwsIllegalArgumentException() {
        when(userRepository.existsByEmail("dup@example.com")).thenReturn(true);

        assertThrows(IllegalArgumentException.class,
                () -> userService.register("Bob", "dup@example.com", "pass123", MembershipType.BRONZE));
    }

    @Test
    void register_blankName_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class,
                () -> userService.register("  ", "valid@example.com", "pass123", MembershipType.BRONZE));
    }

    @Test
    void register_invalidEmail_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class,
                () -> userService.register("Carol", "not-an-email", "pass123", MembershipType.BRONZE));
    }

    @Test
    void register_shortPassword_throwsIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class,
                () -> userService.register("Dave", "dave@example.com", "abc", MembershipType.BRONZE));
    }

    @Test
    void authenticate_correctCredentials_returnsTrue() {
        String hash = BCrypt.hashpw("secret", BCrypt.gensalt());
        User user = new User("Alice", "alice@example.com", hash, MembershipType.GOLD, 45.0);
        when(userRepository.findByEmail("alice@example.com")).thenReturn(Optional.of(user));

        assertTrue(userService.authenticate("alice@example.com", "secret"));
    }

    @Test
    void authenticate_wrongPassword_returnsFalse() {
        String hash = BCrypt.hashpw("secret", BCrypt.gensalt());
        User user = new User("Alice", "alice@example.com", hash, MembershipType.GOLD, 45.0);
        when(userRepository.findByEmail("alice@example.com")).thenReturn(Optional.of(user));

        assertFalse(userService.authenticate("alice@example.com", "wrong"));
    }

    @Test
    void authenticate_unknownEmail_returnsFalse() {
        when(userRepository.findByEmail("nobody@example.com")).thenReturn(Optional.empty());

        assertFalse(userService.authenticate("nobody@example.com", "pass"));
    }

    @Test
    void findByEmail_found_returnsUser() {
        User user = new User("Alice", "alice@example.com", "secret", MembershipType.GOLD, 45.0);
        when(userRepository.findByEmail("alice@example.com")).thenReturn(Optional.of(user));

        Optional<User> result = userService.findByEmail("alice@example.com");

        assertTrue(result.isPresent());
        assertEquals("Alice", result.get().getName());
    }

    @Test
    void findByEmail_notFound_returnsEmpty() {
        when(userRepository.findByEmail("missing@example.com")).thenReturn(Optional.empty());

        assertTrue(userService.findByEmail("missing@example.com").isEmpty());
    }
}
