package com.example.onepasscanada;

import com.example.onepasscanada.controller.CheckInController;
import com.example.onepasscanada.model.CheckIn;
import com.example.onepasscanada.model.Gym;
import com.example.onepasscanada.model.MembershipType;
import com.example.onepasscanada.model.User;
import com.example.onepasscanada.service.CheckInService;
import com.example.onepasscanada.service.GymService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CheckInController.class)
class CheckInControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockitoBean
    GymService gymService;

    @MockitoBean
    CheckInService checkInService;

    @Test
    void checkInPage_noSession_redirectsToLogin() throws Exception {
        mockMvc.perform(get("/checkin"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    void checkInPage_withSession_returnsCheckInViewWithGyms() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("userId", 1L);

        when(gymService.findAll()).thenReturn(List.of(
                new Gym("Test Gym", "123 Test St")
        ));

        mockMvc.perform(get("/checkin").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("checkin"))
                .andExpect(model().attributeExists("gyms"));
    }

    @Test
    void performCheckIn_noSession_redirectsToLogin() throws Exception {
        mockMvc.perform(post("/checkin").param("gymId", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    void performCheckIn_withSession_redirectsToHistory() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("userId", 1L);

        User user = new User("Alex", "alex@example.com", "pw", MembershipType.GOLD, 45.0);
        Gym  gym  = new Gym("Test Gym", "123 Test St");
        gym.setId(1L);
        CheckIn checkIn = new CheckIn(user, gym, LocalDateTime.now(), "Successful");

        when(checkInService.checkIn(1L, 1L)).thenReturn(checkIn);

        mockMvc.perform(post("/checkin").session(session).param("gymId", "1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/history"));
    }
}
