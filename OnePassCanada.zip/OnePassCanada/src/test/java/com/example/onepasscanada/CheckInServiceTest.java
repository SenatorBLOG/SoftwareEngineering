package com.example.onepasscanada;

import com.example.onepasscanada.model.CheckIn;
import com.example.onepasscanada.model.Gym;
import com.example.onepasscanada.model.MembershipType;
import com.example.onepasscanada.model.User;
import com.example.onepasscanada.repository.CheckInRepository;
import com.example.onepasscanada.repository.GymRepository;
import com.example.onepasscanada.repository.UserRepository;
import com.example.onepasscanada.service.CheckInService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CheckInServiceTest {

    @Mock CheckInRepository checkInRepository;
    @Mock UserRepository    userRepository;
    @Mock GymRepository     gymRepository;

    @InjectMocks
    CheckInService checkInService;

    private User user;
    private Gym  gym;

    @BeforeEach
    void setUp() {
        user = new User("Alex", "alex@example.com", "pw", MembershipType.GOLD, 45.0);
        user.setId(1L);

        gym = new Gym("Test Gym", "123 Test St");
        gym.setId(2L);
    }

    @Test
    void checkIn_withinDailyLimit_statusIsSuccessful() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(gymRepository.findById(2L)).thenReturn(Optional.of(gym));
        when(checkInRepository.countByUserAndCheckInTimeBetween(
                eq(user), any(), any())).thenReturn(0L);
        when(checkInRepository.save(any(CheckIn.class))).thenAnswer(inv -> inv.getArgument(0));

        CheckIn result = checkInService.checkIn(1L, 2L);

        assertEquals("Successful", result.getStatus());
        assertEquals(gym, result.getGym());
        assertEquals(user, result.getUser());
    }

    @Test
    void checkIn_dailyLimitReached_statusIsLimitReached() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(gymRepository.findById(2L)).thenReturn(Optional.of(gym));
        // GOLD allows 3 visits/day — mock 3 already done
        when(checkInRepository.countByUserAndCheckInTimeBetween(
                eq(user), any(), any())).thenReturn(3L);
        when(checkInRepository.save(any(CheckIn.class))).thenAnswer(inv -> inv.getArgument(0));

        CheckIn result = checkInService.checkIn(1L, 2L);

        assertEquals("Limit Reached", result.getStatus());
    }

    @Test
    void getTotalCheckInCount_returnsRepositoryCount() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(checkInRepository.countByUser(user)).thenReturn(10L);

        long count = checkInService.getTotalCheckInCount(1L);

        assertEquals(10L, count);
    }

    @Test
    void checkIn_tooSoonAtSameGym_statusIsTooSoon() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(gymRepository.findById(2L)).thenReturn(Optional.of(gym));
        when(checkInRepository.existsByUserAndGymAndCheckInTimeAfter(
                eq(user), eq(gym), any())).thenReturn(true);
        when(checkInRepository.save(any(CheckIn.class))).thenAnswer(inv -> inv.getArgument(0));

        CheckIn result = checkInService.checkIn(1L, 2L);

        assertEquals("Too Soon", result.getStatus());
    }

    @Test
    void getHistoryForUser_returnsOrderedList() {
        CheckIn c1 = new CheckIn(user, gym, java.time.LocalDateTime.now(), "Successful");
        CheckIn c2 = new CheckIn(user, gym, java.time.LocalDateTime.now().minusDays(1), "Successful");

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(checkInRepository.findByUserOrderByCheckInTimeDesc(user)).thenReturn(List.of(c1, c2));

        List<CheckIn> result = checkInService.getHistoryForUser(1L);

        assertEquals(2, result.size());
        assertEquals(c1, result.get(0));
    }
}
