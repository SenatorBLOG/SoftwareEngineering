package com.example.onepasscanada;

import com.example.onepasscanada.controller.HomeController;
import com.example.onepasscanada.model.MembershipType;
import com.example.onepasscanada.model.User;
import com.example.onepasscanada.service.CheckInService;
import com.example.onepasscanada.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(HomeController.class)
class HomeControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockitoBean
    UserService userService;

    @MockitoBean
    CheckInService checkInService;

    @Test
    void home_noSession_redirectsToLogin() throws Exception {
        mockMvc.perform(get("/home"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    void home_withValidSession_returnsHomeView() throws Exception {
        User user = new User("Alex", "alex@example.com", "pw", MembershipType.GOLD, 45.0);
        user.setId(1L);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("userId", 1L);

        when(userService.findById(1L)).thenReturn(Optional.of(user));
        when(checkInService.getTodayCheckInCount(1L)).thenReturn(1L);
        when(checkInService.getTotalCheckInCount(1L)).thenReturn(5L);

        mockMvc.perform(get("/home").session(session))
                .andExpect(status().isOk())
                .andExpect(view().name("home"))
                .andExpect(model().attributeExists("user"))
                .andExpect(model().attribute("todayCount", 1L))
                .andExpect(model().attribute("dailyLimit", 3));
    }

    @Test
    void home_invalidUserId_redirectsToLogin() throws Exception {
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("userId", 99L);

        when(userService.findById(99L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/home").session(session))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }
}
