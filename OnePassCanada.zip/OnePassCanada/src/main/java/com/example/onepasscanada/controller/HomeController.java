package com.example.onepasscanada.controller;

import com.example.onepasscanada.model.User;
import com.example.onepasscanada.service.CheckInService;
import com.example.onepasscanada.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final UserService userService;
    private final CheckInService checkInService;

    public HomeController(UserService userService, CheckInService checkInService) {
        this.userService = userService;
        this.checkInService = checkInService;
    }

    @GetMapping("/home")
    public String home(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/login";
        }

        User user = userService.findById(userId).orElse(null);
        if (user == null) {
            session.invalidate();
            return "redirect:/login";
        }

        long todayCount  = checkInService.getTodayCheckInCount(userId);
        long totalCount  = checkInService.getTotalCheckInCount(userId);
        int  dailyLimit  = user.getMembershipType().getDailyVisitLimit();
        double costPerVisit = totalCount > 0
                ? user.getMembershipType().getMonthlyFee() / totalCount
                : user.getMembershipType().getMonthlyFee();

        model.addAttribute("user",               user);
        model.addAttribute("todayCount",          todayCount);
        model.addAttribute("totalCount",          totalCount);
        model.addAttribute("dailyLimit",          dailyLimit);
        model.addAttribute("effectiveCostPerVisit", String.format("%.2f", costPerVisit));

        return "home";
    }
}
