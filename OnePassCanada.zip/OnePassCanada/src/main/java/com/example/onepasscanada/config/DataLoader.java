package com.example.onepasscanada.config;

import com.example.onepasscanada.model.Gym;
import com.example.onepasscanada.model.MembershipType;
import com.example.onepasscanada.model.User;
import com.example.onepasscanada.repository.GymRepository;
import com.example.onepasscanada.repository.UserRepository;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final GymRepository gymRepository;
    private final UserRepository userRepository;

    public DataLoader(GymRepository gymRepository, UserRepository userRepository) {
        this.gymRepository = gymRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) {
        gymRepository.save(new Gym("Gold's Gym Downtown",    "123 Main St, Vancouver"));
        gymRepository.save(new Gym("Fitness First Midtown",  "456 Burrard St, Vancouver"));
        gymRepository.save(new Gym("Planet Fitness Central", "789 Granville St, Vancouver"));
        gymRepository.save(new Gym("Anytime Fitness",        "321 Broadway, Vancouver"));
        gymRepository.save(new Gym("LA Fitness Eastside",    "654 Commercial Dr, Vancouver"));
        gymRepository.save(new Gym("Equinox Downtown",       "987 Robson St, Vancouver"));
        gymRepository.save(new Gym("Crunch Fitness North",   "147 Lonsdale Ave, North Vancouver"));
        gymRepository.save(new Gym("24 Hour Fitness South",  "258 King George Blvd, Surrey"));

        if (!userRepository.existsByEmail("alex@example.com")) {
            User demo = new User(
                "Alex Johnson", "alex@example.com",
                BCrypt.hashpw("password123", BCrypt.gensalt()),
                MembershipType.GOLD, 45.50
            );
            userRepository.save(demo);
        }

        if (!userRepository.existsByEmail("admin@onepasscanada.com")) {
            User admin = new User(
                "Admin", "admin@onepasscanada.com",
                BCrypt.hashpw("admin123", BCrypt.gensalt()),
                MembershipType.GOLD, 0.0
            );
            admin.setRole("ADMIN");
            userRepository.save(admin);
        }
    }
}
