package com.example.onepasscanada.model;

public enum MembershipType {

    GOLD(3, 45.00),
    SILVER(2, 30.00),
    BRONZE(1, 15.00);

    private final int dailyVisitLimit;
    private final double monthlyFee;

    MembershipType(int dailyVisitLimit, double monthlyFee) {
        this.dailyVisitLimit = dailyVisitLimit;
        this.monthlyFee = monthlyFee;
    }

    public int getDailyVisitLimit() {
        return dailyVisitLimit;
    }

    public double getMonthlyFee() {
        return monthlyFee;
    }
}
