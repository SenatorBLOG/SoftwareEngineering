package com.example.onepasscanada.service;

import com.example.onepasscanada.model.CheckIn;
import com.example.onepasscanada.model.Gym;
import com.example.onepasscanada.model.User;
import com.example.onepasscanada.repository.CheckInRepository;
import com.example.onepasscanada.repository.GymRepository;
import com.example.onepasscanada.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class CheckInService {

    private final CheckInRepository checkInRepository;
    private final UserRepository userRepository;
    private final GymRepository gymRepository;

    public CheckInService(CheckInRepository checkInRepository,
                          UserRepository userRepository,
                          GymRepository gymRepository) {
        this.checkInRepository = checkInRepository;
        this.userRepository = userRepository;
        this.gymRepository = gymRepository;
    }

    public CheckIn checkIn(Long userId, Long gymId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
        Gym gym = gymRepository.findById(gymId)
                .orElseThrow(() -> new IllegalArgumentException("Gym not found: " + gymId));

        LocalDateTime cooldownCutoff = LocalDateTime.now().minusMinutes(30);
        boolean tooSoon = checkInRepository.existsByUserAndGymAndCheckInTimeAfter(user, gym, cooldownCutoff);
        if (tooSoon) {
            CheckIn checkIn = new CheckIn(user, gym, LocalDateTime.now(), "Too Soon");
            return checkInRepository.save(checkIn);
        }

        long todayCount = countTodayCheckIns(user);
        int dailyLimit = user.getMembershipType().getDailyVisitLimit();
        String status = (todayCount < dailyLimit) ? "Successful" : "Limit Reached";

        CheckIn checkIn = new CheckIn(user, gym, LocalDateTime.now(), status);
        return checkInRepository.save(checkIn);
    }

    public List<CheckIn> getHistoryForUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
        return checkInRepository.findByUserOrderByCheckInTimeDesc(user);
    }

    public long getTodayCheckInCount(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
        return countTodayCheckIns(user);
    }

    public long getTotalCheckInCount(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + userId));
        return checkInRepository.countByUser(user);
    }

    public long getTotalSystemCheckIns() {
        return checkInRepository.count();
    }

    private long countTodayCheckIns(User user) {
        LocalDateTime startOfDay = LocalDate.now().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1).minusSeconds(1);
        return checkInRepository.countByUserAndCheckInTimeBetween(user, startOfDay, endOfDay);
    }
}
