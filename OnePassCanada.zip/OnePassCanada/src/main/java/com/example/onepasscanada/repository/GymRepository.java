package com.example.onepasscanada.repository;

import com.example.onepasscanada.model.Gym;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GymRepository extends JpaRepository<Gym, Long> {
}
