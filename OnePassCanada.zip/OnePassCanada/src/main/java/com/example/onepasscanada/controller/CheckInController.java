package com.example.onepasscanada.controller;

import com.example.onepasscanada.service.CheckInService;
import com.example.onepasscanada.service.GymService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class CheckInController {

    private final GymService gymService;
    private final CheckInService checkInService;

    public CheckInController(GymService gymService, CheckInService checkInService) {
        this.gymService = gymService;
        this.checkInService = checkInService;
    }

    @GetMapping("/checkin")
    public String checkInPage(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/login";
        }
        model.addAttribute("gyms", gymService.findAll());
        return "checkin";
    }

    @PostMapping("/checkin")
    public String performCheckIn(@RequestParam Long gymId,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/login";
        }

        try {
            var checkIn = checkInService.checkIn(userId, gymId);
            if ("Successful".equals(checkIn.getStatus())) {
                redirectAttributes.addFlashAttribute("success",
                        "Check-in successful at " + checkIn.getGym().getName() + "!");
            } else if ("Too Soon".equals(checkIn.getStatus())) {
                redirectAttributes.addFlashAttribute("warning",
                        "Please wait 30 minutes between visits to the same gym.");
            } else {
                redirectAttributes.addFlashAttribute("warning",
                        "Daily visit limit reached for your membership tier.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Check-in failed. Please try again.");
        }

        return "redirect:/history";
    }
}
