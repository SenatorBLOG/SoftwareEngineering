package com.example.onepasscanada.repository;

import com.example.onepasscanada.model.CheckIn;
import com.example.onepasscanada.model.Gym;
import com.example.onepasscanada.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface CheckInRepository extends JpaRepository<CheckIn, Long> {
    List<CheckIn> findByUserOrderByCheckInTimeDesc(User user);
    long countByUserAndCheckInTimeBetween(User user, LocalDateTime start, LocalDateTime end);
    long countByUser(User user);
    boolean existsByUserAndGymAndCheckInTimeAfter(User user, Gym gym, LocalDateTime time);
}
