package com.example.onepasscanada.controller;

import com.example.onepasscanada.service.CheckInService;
import com.example.onepasscanada.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {

    private final UserService userService;
    private final CheckInService checkInService;

    public AdminController(UserService userService, CheckInService checkInService) {
        this.userService = userService;
        this.checkInService = checkInService;
    }

    @GetMapping("/admin")
    public String admin(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        String role = (String) session.getAttribute("userRole");
        if (!"ADMIN".equals(role)) return "redirect:/home";

        var users = userService.findAll();
        model.addAttribute("users", users);
        model.addAttribute("totalUsers", users.size());
        model.addAttribute("totalCheckIns", checkInService.getTotalSystemCheckIns());
        return "admin";
    }
}
