package com.example.onepasscanada.service;

import com.example.onepasscanada.model.Gym;
import com.example.onepasscanada.repository.GymRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GymService {

    private final GymRepository gymRepository;

    public GymService(GymRepository gymRepository) {
        this.gymRepository = gymRepository;
    }

    public List<Gym> findAll() {
        return gymRepository.findAll();
    }

    public Optional<Gym> findById(Long id) {
        return gymRepository.findById(id);
    }
}
