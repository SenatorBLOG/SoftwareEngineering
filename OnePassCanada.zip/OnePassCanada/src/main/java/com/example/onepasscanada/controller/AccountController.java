package com.example.onepasscanada.controller;

import com.example.onepasscanada.model.MembershipType;
import com.example.onepasscanada.model.User;
import com.example.onepasscanada.service.CheckInService;
import com.example.onepasscanada.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AccountController {

    private final UserService userService;
    private final CheckInService checkInService;

    public AccountController(UserService userService, CheckInService checkInService) {
        this.userService = userService;
        this.checkInService = checkInService;
    }

    @GetMapping("/account")
    public String account(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        User user = userService.findById(userId).orElse(null);
        if (user == null) { session.invalidate(); return "redirect:/login"; }

        model.addAttribute("user", user);
        model.addAttribute("totalCheckIns", checkInService.getTotalCheckInCount(userId));
        return "account";
    }

    @PostMapping("/account/update")
    public String updateProfile(@RequestParam String newName,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        try {
            userService.updateProfile(userId, newName);
            session.setAttribute("userName", newName);
            redirectAttributes.addFlashAttribute("success", "Name updated successfully.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/account";
    }

    @PostMapping("/account/password")
    public String changePassword(@RequestParam String currentPassword,
                                 @RequestParam String newPassword,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        try {
            userService.changePassword(userId, currentPassword, newPassword);
            redirectAttributes.addFlashAttribute("success", "Password changed successfully.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/account";
    }

    @GetMapping("/membership")
    public String membership(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        User user = userService.findById(userId).orElse(null);
        if (user == null) { session.invalidate(); return "redirect:/login"; }

        model.addAttribute("user", user);
        model.addAttribute("tiers", MembershipType.values());
        return "membership";
    }

    @PostMapping("/membership/change")
    public String changeMembership(@RequestParam MembershipType newTier,
                                   HttpSession session,
                                   RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return "redirect:/login";

        try {
            userService.changeMembership(userId, newTier);
            redirectAttributes.addFlashAttribute("success",
                    "Membership changed to " + newTier.name() + ".");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/membership";
    }
}
