package com.example.onepasscanada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnePassCanadaApplication {

    public static void main(String[] args) {
        SpringApplication.run(OnePassCanadaApplication.class, args);
    }

}
