package com.example.onepasscanada.controller;

import com.example.onepasscanada.service.CheckInService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HistoryController {

    private final CheckInService checkInService;

    public HistoryController(CheckInService checkInService) {
        this.checkInService = checkInService;
    }

    @GetMapping("/history")
    public String history(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/login";
        }

        var checkIns = checkInService.getHistoryForUser(userId);
        model.addAttribute("checkIns", checkIns);
        model.addAttribute("totalCount", checkIns.size());

        return "history";
    }
}
